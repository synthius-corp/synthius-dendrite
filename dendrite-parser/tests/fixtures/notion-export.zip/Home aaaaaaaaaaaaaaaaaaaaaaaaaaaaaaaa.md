# Synthetic home

Synthetic person records a calm morning routine, a collaborative project, a family call, and a plan to learn a new language next month.